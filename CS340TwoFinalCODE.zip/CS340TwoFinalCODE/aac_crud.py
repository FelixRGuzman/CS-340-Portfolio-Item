from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    # Will comment out previous hard coded function to add a new one
    """
    def__init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'newPass123'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34890
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
    """

    # Current Function
    def __init__(self, user='aacuser', password='newPass123', host='nv-desktop-services.apporto.com',
                 port=34890, db='AAC', col='animals'):

        USER = user
        PASS = password
        HOST = host
        PORT = port
        DB = db
        COL = col

        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
      

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary            
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Create method to implement the R in CRUD.
    def read(self, query):
        if query is not None:
            result = list(self.database.animals.find(query))
            return result
        else:
            raise Exception("Nothing to read, because query parameter is empty")

    # Create method to implement the U in CRUD.
    def update(self, query, new_values, many=False):
        if query is not None and new_values is not None:
            if many:
                result = self.database.animals.update_many(query, {"$set": new_values})
            else:
                result = self.database.animals.update_one(query, {"$set": new_values})
            return result.modified_count
        else:
            raise Exception("Nothing to update, because query or new_values parameter is empty")

    # Create method to implement the D in CRUD.
    def delete(self, query, many=False):
        if query is not None:
            if many:
                result = self.database.animals.delete_many(query)
            else:
                result = self.database.animals.delete_one(query)
            return result.deleted_count
        else:
            raise Exception("Nothing to delete, because query parameter is empty")
